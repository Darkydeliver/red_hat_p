#!/bin/bash

# Create the output directory if it does not exist
output_dir="Linux_output/Collection"
mkdir -p $output_dir

# Output file
output_file="${output_dir}/T1560.001_Collection.txt"

# Function to log and display output
log_and_display() {
    echo "$1" | tee -a "$output_file"
}

# Start logging
log_and_display "Starting SISA Tests for T1560.001 Collection at $(date)"

# Function to check and install dependencies based on OS type
install_dependencies() {
    if [[ -f /etc/redhat-release ]]; then
        # For CentOS/RHEL
        if ! command -v yum &> /dev/null; then
            log_and_display "Yum is not installed, installing dependencies..."
            sudo yum install -y zip gpg openssl python3
        fi
    elif [[ -f /usr/local/etc/pkg/repos/FreeBSD.conf ]]; then
        # For FreeBSD
        if ! command -v pkg &> /dev/null; then
            log_and_display "Pkg is not installed, installing dependencies..."
            sudo pkg install -y zip gpg openssl python3
        fi
    elif [[ -f /etc/debian_version ]]; then
        # For Debian/Ubuntu
        if ! command -v apt-get &> /dev/null; then
            log_and_display "Apt-get is not installed, installing dependencies..."
            sudo apt-get update && sudo apt-get install -y zip gpg openssl python3
        fi
    else
        log_and_display "Unsupported OS, cannot install dependencies."
        exit 1
    fi
}

# Check and install dependencies
install_dependencies

# Function to run a test
run_test() {
    local test_name="$1"
    local attack_command="$2"
    local cleanup_command="$3"
    local check_prereq_command="$4"
    local get_prereq_command="$5"

    log_and_display "Running $test_name..."

    # Check prerequisites
    eval "$check_prereq_command"
    if [ $? -ne 0 ]; then
        log_and_display "Prerequisites not met for $test_name. Trying to install..."
        eval "$get_prereq_command"
        if [ $? -ne 0 ]; then
            log_and_display "Failed to install prerequisites for $test_name. Skipping test."
            return
        fi
    fi

    # Run attack command
    eval "$attack_command"
    if [ $? -ne 0 ]; then
        log_and_display "Failed to run $test_name."
    else
        log_and_display "$test_name ran successfully."
    fi

    # Run cleanup command
    eval "$cleanup_command"
    if [ $? -ne 0 ]; then
        log_and_display "Failed to clean up after $test_name."
    else
        log_and_display "Cleaned up after $test_name."
    fi
}

# Test 1: Compressing data using GZip in Python
run_test "Compressing data using GZip in Python" \
    "which_python=\`which python3\`; \$which_python -c \"import gzip; input_file=open('/etc/passwd', 'rb'); content=input_file.read(); input_file.close(); output_file=gzip.GzipFile('/tmp/passwd.gz','wb',compresslevel=6); output_file.write(content); output_file.close();\"" \
    "rm /tmp/passwd.gz" \
    "which python3" \
    "echo 'please install python3 to run this test'; exit 1"

# Test 2: Compressing data using bz2 in Python
run_test "Compressing data using bz2 in Python" \
    "which_python=\`which python3\`; \$which_python -c \"import bz2; input_file=open('/etc/passwd','rb'); content=input_file.read(); input_file.close(); bz2content=bz2.compress(content,compresslevel=9); output_file=open('/tmp/passwd.bz2','wb'); output_file.write(bz2content); output_file.close();\"" \
    "rm /tmp/passwd.bz2" \
    "which python3" \
    "echo 'please install python3 to run this test'; exit 1"

# Test 3: Compressing data using zipfile in Python
run_test "Compressing data using zipfile in Python" \
    "which_python=\`which python3\`; \$which_python -c \"from zipfile import ZipFile; ZipFile('/tmp/passwd.zip', mode='w').write('/etc/passwd')\"" \
    "rm /tmp/passwd.zip" \
    "which python3" \
    "echo 'please install python3 to run this test'; exit 1"

# Test 4: Compressing data using tarfile in Python
run_test "Compressing data using tarfile in Python" \
    "which_python=\`which python3\`; \$which_python -c \"import tarfile; tar = tarfile.open('/tmp/passwd.tar.gz', 'w:gz'); tar.add('/etc/passwd'); tar.close()\"" \
    "rm /tmp/passwd.tar.gz" \
    "which python3" \
    "echo 'please install python3 to run this test'; exit 1"

# Test 5: Data Compressed - nix - zip
run_test "Data Compressed - nix - zip" \
    "zip \$HOME/data.zip /var/log/{w,b}tmp" \
    "rm -f \$HOME/data.zip" \
    "if [ \$(ls /var/log/{w,b}tmp 2>/dev/null | wc -l) > 0 ] && [ -x \$(which zip) ]; then exit 0; else exit 1; fi;" \
    "(which yum && yum -y install epel-release zip) || (which apt-get && apt-get install -y zip); echo 'Please set input_files argument to include files that exist'"

# Test 6: Data Compressed - nix - gzip Single File
run_test "Data Compressed - nix - gzip Single File" \
    "test -e \$HOME/victim-gzip.txt && gzip -k \$HOME/victim-gzip.txt || (echo 'confidential! SSN: 078-05-1120 - CCN: 4000 1234 5678 9101' >> \$HOME/victim-gzip.txt; gzip -k \$HOME/victim-gzip.txt)" \
    "rm -f \$HOME/victim-gzip.txt.gz" \
    "which gzip" \
    "echo 'please install gzip to run this test'; exit 1"

# Test 7: Data Compressed - nix - tar Folder or File
run_test "Data Compressed - nix - tar Folder or File" \
    "tar -cvzf \$HOME/data.tar.gz \$HOME/\$USERNAME" \
    "rm -f \$HOME/data.tar.gz" \
    "test -e \$HOME/\$USERNAME" \
    "mkdir -p \$HOME/\$USERNAME && touch \$HOME/\$USERNAME/file1"

# Test 8: Data Encrypted with zip and gpg symmetric
run_test "Data Encrypted with zip and gpg symmetric" \
    "mkdir -p /tmp/T1560; cd /tmp/T1560; touch a b c d e f g; zip --password 'InsertPasswordHere' /tmp/T1560/T1560 ./*; echo 'InsertPasswordHere' | gpg --batch --yes --passphrase-fd 0 --output /tmp/T1560/T1560.zip.gpg -c /tmp/T1560/T1560.zip; ls -l /tmp/T1560" \
    "rm -Rf /tmp/T1560" \
    "if [ ! -x \"\$(command -v gpg)\" ] || [ ! -x \"\$(command -v zip)\" ]; then exit 1; fi;" \
    "(which pkg && pkg install -y gnupg zip) || (which yum && yum -y install epel-release zip gpg) || (which apt-get && apt-get install -y zip gpg)"

# Test 9: Encrypts collected data with AES-256 and Base64
run_test "Encrypts collected data with AES-256 and Base64" \
    "zip -r /tmp/t1560/t1560_data.zip /tmp/t1560; openssl enc -aes-256-cbc -pass pass:SISA_enc_pass -p -in /tmp/t1560/t1560_data.zip -out /tmp/t1560/t1560_data.enc; cat /tmp/t1560/t1560_data.enc | base64" \
    "rm -rf /tmp/t1560" \
    "if [ ! -d /tmp/t1560 ]; then exit 1; else exit 0; fi;" \
    "if [ ! -d /tmp/t1560 ]; then mkdir -p /tmp/t1560; cd /tmp/t1560; touch {a..z}.data; fi"

# End logging
log_and_display "Completed SISA Tests for T1560.001 Collection at $(date)"

