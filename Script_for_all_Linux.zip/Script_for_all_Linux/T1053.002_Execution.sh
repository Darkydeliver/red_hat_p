#!/bin/bash

# Function to install `at` and start `atd` daemon
setup_at_scheduler() {
    # Check if `at` is installed
    if ! command -v at >/dev/null 2>&1; then
        echo "Installing 'at' scheduler..."
        if [ "$(uname)" = 'FreeBSD' ]; then
            pkg install -y at || { echo 'Failed to install `at`. Please install it manually.'; exit 1; }
        elif [ -x "$(command -v apt-get)" ]; then
            apt-get update
            apt-get install -y at || { echo 'Failed to install `at`. Please install it manually.'; exit 1; }
        elif [ -x "$(command -v yum)" ]; then
            yum install -y at || { echo 'Failed to install `at`. Please install it manually.'; exit 1; }
        elif [ -x "$(command -v dnf)" ]; then
            dnf install -y at || { echo 'Failed to install `at`. Please install it manually.'; exit 1; }
        elif [ -x "$(command -v pacman)" ]; then
            pacman -Sy --noconfirm at || { echo 'Failed to install `at`. Please install it manually.'; exit 1; }
        else
            echo 'Unsupported package manager. Please install `at` manually.'
            exit 1
        fi
    fi

    # Ensure `atd` daemon is running
    if [ "$(uname)" = 'Linux' ]; then
        systemctl start atd || service atd start
        if ! systemctl is-active --quiet atd; then
            echo "Failed to start `atd`. Please start it manually."
            exit 1
        fi
    fi

    echo "'at' scheduler setup complete."
}

# Check for prerequisites and install `at` if necessary
setup_at_scheduler

# Input parameters
time_spec="now + 1 minute"
at_command="echo Hello from SISA"

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Execution"
mkdir -p "$output_folder"

# Schedule the job and capture the output
output_file="$output_folder/T1053.002_Execution.txt"
{
    echo "Scheduling job with at:"
    echo "$at_command" | at "$time_spec"
    echo "Job scheduled to run at $time_spec."
} > "$output_file" 2>&1

echo "Execution completed. Output saved to $output_file"

