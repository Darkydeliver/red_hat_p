#!/bin/bash

# Description: This script demonstrates creating a directory and file with a space at the end of their names
#              to test masquerading with a space after the filename.

# Create a temporary directory for the test
mkdir -p /tmp/atomic-test-T1036.006
cd /tmp/atomic-test-T1036.006

# Create a directory with a space at the end of its name
mkdir -p 'testdirwithspaceend '

# Create a script with a space at the end of its name
echo "#!/bin/bash" > 'testdirwithspaceend /init '
echo 'echo "running T1035.006 with space after filename to masquerade init"' >> 'testdirwithspaceend /init '
echo "sleep 5" >> 'testdirwithspaceend /init '

# Make the script executable
chmod +x 'testdirwithspaceend /init '

# Execute the script
'./testdirwithspaceend /init '

# Cleanup function
cleanup() {
    echo "Cleaning up..."
    rm -rf /tmp/atomic-test-T1036.006
    echo "Cleanup completed."
}

# Register cleanup function to be called on script exit
trap cleanup EXIT

# End of script

