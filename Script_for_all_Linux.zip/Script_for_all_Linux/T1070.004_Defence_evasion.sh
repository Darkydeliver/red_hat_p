#!/bin/bash

# Function to check and create prerequisite files/folders
check_and_create_prereqs() {
    local file_to_check="$1"
    local folder_to_check="$2"
    
    if [ ! -e "$file_to_check" ]; then
        mkdir -p "$folder_to_check"
        touch "$file_to_check"
    fi
}

# Function to save script output to a text file
save_output_to_file() {
    local output="$1"
    local filename="$2"

    local output_folder="Linux_output/Defence_Evasion"
    local output_file="$output_folder/$filename"

    # Create output folder if it doesn't exist
    mkdir -p "$output_folder"

    # Save output to file
    echo "$output" > "$output_file"
}

# Function to install dependencies for different Linux distributions
install_dependencies() {
    # Check and install dependencies for Ubuntu/Debian-based systems
    if [ -f /etc/debian_version ]; then
        echo "Ubuntu/Debian detected. Installing dependencies..."
        sudo apt update
        sudo apt install -y coreutils shred
    # Check and install dependencies for RedHat/CentOS/Fedora-based systems
    elif [ -f /etc/redhat-release ]; then
        echo "RedHat/CentOS/Fedora detected. Installing dependencies..."
        sudo yum install -y coreutils shred
    # Check and install dependencies for Oracle Linux
    elif [ -f /etc/oracle-release ]; then
        echo "Oracle Linux detected. Installing dependencies..."
        sudo dnf install -y coreutils shred
    else
        echo "Unsupported Linux distribution. Please ensure coreutils and shred are installed manually."
        exit 1
    fi
}

# SISA Test #1 - Delete a single file
test1() {
    local parent_folder="/tmp/victim-files/"
    local file_to_delete="${parent_folder}T1070.004-test.txt"
    
    # Check and create prerequisite file
    check_and_create_prereqs "$file_to_delete" "$parent_folder"
    
    # Delete the single file
    echo "Running SISA Test #1: Deleting a single file..."
    rm -f "$file_to_delete"
    
    # Cleanup
    echo "Cleaning up SISA Test #1..."
    rm -rf "$parent_folder"
    echo "SISA Test #1 completed."
}

# SISA Test #2 - Delete an entire folder
test2() {
    local folder_to_delete="/tmp/victim-folder"
    
    # Check and create prerequisite folder
    if [ ! -e "$folder_to_delete" ]; then
        mkdir -p "$folder_to_delete"
    fi
    
    # Delete the entire folder
    echo "Running SISA Test #2: Deleting an entire folder..."
    rm -rf "$folder_to_delete"
    echo "SISA Test #2 completed."
}

# SISA Test #3 - Overwrite and delete a file with shred
test3() {
    local file_to_shred="/tmp/victim-shred.txt"
    
    # Check and create prerequisite file
    check_and_create_prereqs "$file_to_shred" "/tmp"
    
    # Overwrite and delete the file with shred
    echo "Running SISA Test #3: Overwriting and deleting a file with shred..."
    shred -u "$file_to_shred"
    echo "SISA Test #3 completed."
}

# Main script execution
main() {
    echo "Starting Indicator Removal on Host: File Deletion tests..."

    # Install necessary dependencies
    install_dependencies

    # Capture all output
    output=$( {
        echo "Starting Indicator Removal on Host: File Deletion tests..."
        test1
        test2
        test3
        echo "All tests completed."
    } 2>&1 )

    # Save output to file
    save_output_to_file "$output" "T1070.004_Defence_evasion.txt"

    echo "All tests completed."
}

# Run the main function
main

