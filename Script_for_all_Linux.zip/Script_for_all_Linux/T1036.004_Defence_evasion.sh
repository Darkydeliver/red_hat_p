#!/bin/bash

# Ensure the output directory exists
output_dir="./Linux_output/Defence_Evasion"
mkdir -p "$output_dir"

# Output file
output_file="$output_dir/T1036.004_Defence_evasion.txt"

# Atomic Test #3 - Rename /proc/pid/comm using prctl
# This test runs a C program that calls prctl(PR_SET_NAME) to modify /proc/pid/comm value to "totally_legit".

exe_path="/tmp/T1036_004_prctl_rename"
c_file_path="/tmp/prctl_rename.c"

# Check for necessary permissions and compilation tool
if ! command -v cc &>/dev/null; then
    echo "C compiler not found. Please install gcc or cc." | tee -a "$output_file"
    exit 1
fi

# Create the C program
cat << 'EOF' > "$c_file_path"
#include <stdio.h>
#include <sys/prctl.h>
#include <unistd.h>

int main() {
    prctl(PR_SET_NAME, "totally_legit", 0, 0, 0);
    while (1) {
        sleep(10);
    }
    return 0;
}
EOF

# Compile the C program
cc -o "$exe_path" "$c_file_path" 2>> "$output_file"
if [ $? -ne 0 ]; then
    echo "Compilation failed." | tee -a "$output_file"
    rm -f "$c_file_path"
    exit 1
fi

# Run the executable in the background
"$exe_path" &
pid=$!

# Give it a moment to start
sleep 1

# Check if the process name has been changed
TMP=$(ps -p "$pid" -o comm=)

if [ "$TMP" == "totally_legit" ]; then
    echo "Renamed process FOUND in process list" | tee -a "$output_file"
    echo "Process ID: $pid, Name: $TMP" | tee -a "$output_file"
else
    echo "Renamed process NOT FOUND in process list" | tee -a "$output_file"
fi

# Cleanup: terminate the background process and remove files
kill "$pid" 2>/dev/null
rm -f "$exe_path" "$c_file_path"
echo "Cleanup done. All chosen SISA tests executed." | tee -a "$output_file"
exit 0

