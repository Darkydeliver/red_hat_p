
#T1040 
echo "T1040 cleanup"
program_name="linux_pcapdemo"
program_c_file="/tmp/${program_name}.c"
program_executable="/tmp/${program_name}"

echo "Cleaning up..."
rm -f $program_c_file $program_executable
echo "Cleanup completed."
#------------------------------------------------------

#T1053.003 -Execution.sh
echo "T1053.003 - Execution Cleanup"
echo "Test 1 Cleanup"
crontab /tmp/notevil

echo "Test 2 Cleanup"
#command_SISA_2="echo 'Hello from SISA Team' > /tmp/SISA.log"
cron_script_name_SISA_2="persistevil"

rm /etc/cron.daily/${cron_script_name_SISA_2} -f
rm /etc/cron.hourly/${cron_script_name_SISA_2} -f
rm /etc/cron.monthly/${cron_script_name_SISA_2} -f
rm /etc/cron.weekly/${cron_script_name_SISA_2} -f

echo "Test 3 Cleanup "
#command_SISA_3="echo '*/5 * * * * root echo \"Hello from SISA Team\"' > /tmp/SISA.log"
cron_script_name_SISA_3="persistevil"
rm /etc/cron.d/${cron_script_name_SISA_3} -f

echo "Test 4 Cleanup "
rm /var/spool/cron/crontabs/${cron_script_name_SISA_3} -f
#----------------------------------------------------------------

#T1053.006
echo "T1053.006 Cleanup"
path_to_systemd_service="/etc/systemd/system/sisa-timer.service"
path_to_systemd_timer="/etc/systemd/system/sisa-timer.timer"
systemd_service_name="sisa-timer.service"
systemd_timer_name="sisa-timer.timer"

systemctl stop ${systemd_timer_name}
systemctl disable ${systemd_timer_name}
rm ${path_to_systemd_service}
rm ${path_to_systemd_timer}
systemctl daemon-reload
#-----------------------------------------------------------------


#Exfiltration

echo "Exfiltration Cleanup"
HOSTNAME=$(hostname)
ZIPPED_FILE="${HOSTNAME}.zip"

rm ${ZIPPED_FILE}
rm "Exfildata.txt"
rm "Exfiltrated_data.zip"
rm "passwd.zip"

echo "removed zip files"
echo ""

#------------------

#Deleting users

# Define the users to check
USERS=("Bastest" "testuser")

# Loop through each user
for user in "${USERS[@]}"; do
    if getent passwd "$user" > /dev/null; then
        echo "User $user exists. Deleting..."
        sudo userdel -r "$user" && echo "User $user and their home directory have been deleted."
    else
        echo "User $user does not exist."
    fi
done
#------------------------------

