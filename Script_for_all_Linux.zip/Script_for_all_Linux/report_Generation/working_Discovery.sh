import pandas as pd
import re
from datetime import datetime

# Load the Excel file
file_path = 'NEPS - BAS.xlsx'
df = pd.read_excel(file_path)

# Display the columns in the loaded Excel file
print("Columns in the loaded Excel file:")
print(df.columns)

# Get the log column dynamically
log_column = df.columns[df.columns.str.contains('message', case=False)].tolist()
if not log_column:
    raise ValueError("No suitable log column found.")
log_column = log_column[0]  # Get the first match

# Load the commands to search for
commands = [
    'argc=2 a0="who" a1="-a"',
    'argc=1 a0="w"',
    'argc=1 a0="users"',
    'argc=2 a0="cat" a1="/etc/passwd"',
    'argc=3 a0="sudo" a1="cat" a2="/etc/sudoers"',
    'argc=3 a0="grep" a1="*:0:" a2="/etc/passwd"',
    'argc=1 a0="uname"',
    'argc=1 a0="groups"',
    'argc=1 a0="systemd-detect-virt"',
    'argc=2 a0="systemctl" a1="--type=service"',
    'argc=3 a0="sudo" a1="smbstatus" a2="--shares"',
    'argc=2 a0="uname" a1="-a"',
    'argc=2 a0="cat" a1="/etc/issue"',
    'argc=2 a0="cat" a1="/etc/os-release"',
    'argc=1 a0="uptime"',
    'argc=2 a0="cat" a1="/sys/class/dmi/id/product_name"',
    'argc=3 a0="grep" a1="-i" a2="microsoft|vmware|virtualbox|quemu|domu"',
    'argc=1 a0="hostname"',
    'argc=1 a0="env"',
    'argc=8 a0="find" a1="/" a2="-path" a3=".mozilla/firefox//places.sqlite" a4="-exec" a5="echo" a6="{}" a7=";"',
    'argc=8 a0="find" a1="/" a2="-path" a3="/Google/Chrome//Bookmarks" a4="-exec" a5="echo" a6="{}" a7=";"',
    'argc=2 a0="arp" a1="-a"',
    'argc=1 a0="ifconfig"',
    'argc=2 a0="netstat" a1="-an"',
    'argc=2 a0="ls" a1="-a"',
    'argc=9 a0="sed" a1="-e" a2="s/:$//" a3="-e" a4="s/[^-][^/]*//--/g" a5="-e" a6=732F5E2F202F a7="-e" a8="s/-/|/"',
    'argc=1 a0="netstat"',
    'argc=2 a0="who" a1="-a"',
    'argc=2 a0="ps" a1="aux"',
    'argc=1 a0="groups"',
    'argc=2 a0="getent" a1="group"',
    'argc=1 a0="id"',
    'argc=2 a0="cat" a1="/etc/pam.d/common-password"',
    'argc=1 a0="locale"',
    'argc=2 a0="ps" a1="aux"',
    'argc=2 a0="arp" a1="-a"',
    'argc=2 a0="grep" a1="default"',
    'argc=4 a0="ip" a1="route" a2="get" a3="1"'
]

# Function to search for commands in logs
def find_commands(log, commands):
    if isinstance(log, str):  # Ensure log is a string
        log = log.lower().strip()  # Ensure log is lowercase and stripped of extra spaces
        for command in commands:
            command_str = command.split(' ')
            if all(part in log for part in command_str):
                return True
    return False

# Function to extract time from a log message using regex
def extract_time(log):
    time_pattern = r'\b(\d{2}:\d{2}:\d{2})\b'  # Matches HH:MM:SS format
    match = re.search(time_pattern, log)
    if match:
        return match.group(0)  # Return the first matched time string
    return None

# Since there is no 'type' column, directly process the entire DataFrame
# Filter the DataFrame to only include rows where 'message' or 'alarm_name' is not empty
filtered_df = df[(df['message'].notna()) | (df['alarm_name'].notna())]

# Apply the function to search for commands in the log column
filtered_df['Contains Command'] = filtered_df[log_column].apply(lambda log: find_commands(log, commands))

# Filter rows where a command was found
matching_logs = filtered_df[filtered_df['Contains Command']]

# Extract time from each log message
matching_logs['Extracted Time'] = matching_logs[log_column].apply(extract_time)

# Remove rows where no time could be extracted
matching_logs = matching_logs[matching_logs['Extracted Time'].notna()]

# Convert extracted time to datetime object for comparison
matching_logs['Extracted Time'] = matching_logs['Extracted Time'].apply(lambda x: datetime.strptime(x, '%H:%M:%S'))

# Remove duplicates and keep the most recent log based on the extracted time
matching_logs = matching_logs.sort_values('Extracted Time').drop_duplicates(subset=log_column, keep='last')

# Add the 'Tactic Name' column with the value 'Discovery'
matching_logs['Tactic Name'] = 'Discovery'

# Reorder the columns so that 'Tactic Name' is first
matching_logs = matching_logs[['Tactic Name'] + matching_logs.columns[:-1].tolist()]

# Output the result to a new Excel file
output_path = 'matching_logs_with_tactic.xlsx'
matching_logs.to_excel(output_path, index=False)
print(f"Found {len(matching_logs)} matching logs. Results saved to {output_path}.")

