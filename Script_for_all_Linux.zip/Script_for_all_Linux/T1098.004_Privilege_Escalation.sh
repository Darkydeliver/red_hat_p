#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Privilege_Escalation"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1098.004_Privilege_Escalation.txt"

# Function to perform Atomic Test #1 - Modify SSH Authorized Keys
function modify_ssh_authorized_keys {
    local user_home="$1"
    local ssh_dir="$user_home/.ssh"
    local authorized_keys_file="$ssh_dir/authorized_keys"

    echo "Starting SISA Test #1: Modify SSH Authorized Keys" | tee -a "$output_file"

    # Check if the .ssh directory exists, if not, create it
    if [ ! -d "$ssh_dir" ]; then
        mkdir -p "$ssh_dir"
        echo "Created directory: $ssh_dir" | tee -a "$output_file"
    else
        echo "Directory already exists: $ssh_dir" | tee -a "$output_file"
    fi

    # Check if the authorized_keys file exists, if not, create it
    if [ ! -f "$authorized_keys_file" ]; then
        touch "$authorized_keys_file"
        echo "Created file: $authorized_keys_file" | tee -a "$output_file"
    else
        echo "File already exists: $authorized_keys_file" | tee -a "$output_file"
    fi

    # Modify the authorized_keys file
    if [ -f "$authorized_keys_file" ]; then
        ssh_authorized_keys=$(cat "$authorized_keys_file")
        echo "$ssh_authorized_keys" > "$authorized_keys_file"
        echo "SSH authorized_keys file modified successfully." | tee -a "$output_file"
    else
        echo "Error: $authorized_keys_file not found." | tee -a "$output_file"
    fi
}

# Function to check the platform and ensure compatibility
function check_platform {
    platform=$(uname)

    case "$platform" in
        "Linux")
            echo "Platform detected: Linux"
            ;;
        *)
            echo "Platform detected: $platform (not supported)"
            exit 1
            ;;
    esac
}

# Main script logic to execute the atomic test
{
    echo "=========================================================="
    echo "               Executing Chosen SISA Test                 "
    echo "=========================================================="

    # Ensure platform compatibility
    check_platform

    # Modify the following path to the home directory of the user you want to target
    target_user_home="/home/kali"  # Change to the appropriate user's home directory if necessary
    
    # Check if the target user home directory exists
    if [ -d "$target_user_home" ]; then
        modify_ssh_authorized_keys "$target_user_home"
    else
        echo "Error: Target user home directory does not exist. Exiting." | tee -a "$output_file"
        exit 1
    fi

    echo "=========================================================="
    echo "            All Chosen SISA Tests Executed                "
    echo "=========================================================="
} | tee -a "$output_file"

echo "Execution completed. Output saved to $output_file"

