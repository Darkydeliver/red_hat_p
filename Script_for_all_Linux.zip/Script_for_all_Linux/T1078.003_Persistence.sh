#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Persistence"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1078.003_Persistence.txt"

# Function to create local account (Linux and FreeBSD)
create_local_account() {
    local username="art"
    local password=$(openssl passwd -1 art)
    
    # Check if user 'art' already exists
    if id "$username" &>/dev/null; then
        echo "User 'art' already exists. Skipping creation."
    else
        # Create the user 'art' with /bin/bash shell and home directory
        if [ "$(uname)" = 'Linux' ]; then
            if command -v useradd &>/dev/null; then
                sudo useradd --shell /bin/bash --create-home --password $password $username
            elif command -v adduser &>/dev/null; then
                sudo adduser --shell /bin/bash --disabled-password --gecos "" $username
                echo "$username:$password" | sudo chpasswd
            else
                echo "Error: useradd or adduser command not found. Manual user creation required."
                exit 1
            fi
        elif [ "$(uname)" = 'FreeBSD' ]; then
            sudo pw useradd $username -g wheel -s /bin/sh
            echo $password | sudo pw mod user $username -h 0
        else
            echo "Unsupported platform $(uname)"
            return 1
        fi
    fi
    
    # Switch to user 'art', execute whoami, and exit
    sudo su $username -c "whoami; exit"
    
    # Cleanup: Delete user 'art'
    if [ "$(uname)" = 'Linux' ]; then
        sudo userdel $username -rf
    elif [ "$(uname)" = 'FreeBSD' ]; then
        sudo rmuser -y $username
    fi
}

# Function to reactivate a locked/expired account (Linux and FreeBSD)
reactivate_account() {
    local username="art"
    local password=$(openssl passwd -1 art)
    
    # Create the user 'art' if it does not exist
    if ! id "$username" &>/dev/null; then
        if [ "$(uname)" = 'Linux' ]; then
            if command -v useradd &>/dev/null; then
                sudo useradd --shell /bin/bash --create-home --password $password $username
            elif command -v adduser &>/dev/null; then
                sudo adduser --shell /bin/bash --disabled-password --gecos "" $username
                echo "$username:$password" | sudo chpasswd
            else
                echo "Error: useradd or adduser command not found. Manual user creation required."
                exit 1
            fi
        elif [ "$(uname)" = 'FreeBSD' ]; then
            sudo pw useradd $username -g wheel -s /bin/sh
            echo $password | sudo pw mod user $username -h 0
        else
            echo "Unsupported platform $(uname)"
            return 1
        fi
    fi
    
    # Lock and expire the account, then unlock and renew it
    if [ "$(uname)" = 'Linux' ]; then
        sudo usermod --lock $username
        sudo usermod --expiredate "1" $username
        sudo usermod --unlock $username
        sudo usermod --expiredate "99999" $username
    elif [ "$(uname)" = 'FreeBSD' ]; then
        sudo pw lock $username
        sudo pw expire $username
        sudo pw unlock $username
        sudo pw mod user $username -e 0
    fi
    
    # Switch to user 'art', execute whoami, and exit
    sudo su $username -c "whoami; exit"
    
    # Cleanup: Delete user 'art'
    if command -v userdel &>/dev/null; then
        sudo userdel -r $username
    elif command -v deluser &>/dev/null; then
        sudo deluser --remove-home $username
    fi
}

# Function to login as nobody (Linux)
login_as_nobody() {
    local username="nobody"
    local password=$(openssl passwd -1 nobody)
    
    # Change login shell of 'nobody' to /bin/bash
    sudo chsh --shell /bin/bash $username
    
    # Change password of 'nobody' to 'nobody'
    sudo usermod --password $password $username
    
    # Switch to user 'nobody', execute whoami, and exit
    sudo su $username -c "whoami; exit"
    
    # Reset 'nobody' shell to /usr/sbin/nologin
    sudo chsh --shell /usr/sbin/nologin $username
}

# Main script execution
{
    echo "Running Persistence Test - T1078.003 #8 - Create local account (Linux and FreeBSD)"
    create_local_account

    echo "Running Persistence Test - T1078.003 #9 - Reactivate a locked/expired account (Linux and FreeBSD)"
    reactivate_account

    echo "Running Persistence Test - T1078.003 #11 - Login as nobody (Linux)"
    login_as_nobody

    echo "Tests completed."
} | tee "$output_file"

echo "Execution completed. Output saved to $output_file"

